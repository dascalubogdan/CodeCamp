﻿/// <reference path="c:\users\bogdan.dascalu\documents\visual studio 2015\Projects\SFHtmlClient\SFHtmlClient\Scripts/jquery-3.1.1.js" />

$(document).ready(function () {
    for (var i = 0; i < 200; i++)
    {
        var divbox = document.createElement('div');
        $(divbox).text(0);
        $(divbox).attr('id', 'box' + i);
        $(divbox).attr('class', 'box')
        $(divbox).attr('requestNumber', 0);
        $('body').append(divbox);               
          
        callSetInterval(divbox);
    }
})

function callSetInterval(divbox) {
   // var interval = Math.floor((Math.random() * 10000) + 1000);

    // setInterval(function () { setupRequests(divbox); }, 2000);
    setupRequests(divbox);
}

function setupRequests(divbox)
{  
    $.get('http://vbodascdemo.westeurope.cloudapp.azure.com:8850/api/colors/' + $(divbox).attr('id'))
    .done(function (response) {
        var nodeName = 'N' + response['NodeName'];
        var requestNumber = response['RequestCount'];

        $(divbox).html('<label>' + nodeName + ' ' + requestNumber + '</label>');
        $(divbox).css('background-color', response['Color']);

        var node = $('#' + nodeName);
        node.attr('count', parseInt(node.attr('count')) + 1);
        node.text(nodeName + '= ' + node.attr('count'));

        setupRequests($(divbox)[0]);
    });
        
}
