﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Net.Http;
using System.Windows.Forms;
using Newtonsoft.Json;
using System.Linq;

namespace ColorServiceClient
{
    public partial class Form1 : Form
    {
        private void CreateRequests(int boxId)
        {
            Timer timer = new Timer();
            timer.Tick += CreateRequest;
            timer.Tag = boxId;
            timer.Interval = new Random(boxId).Next(500, 3000);
            timer.Start();
        }

        private void CreateAndAddNodes()
        {
            for (int i = 0; i < 100; i++)
            {
                var box = CreateBoxes(i);
                boxes.Add(box);
                this.flowLayoutPanel.Controls.Add(box);
                CreateRequests(i);
            }
        }

        private async void CreateRequest(object sender, EventArgs e)
        {
            string boxId = GetBoxId(sender);

            var client = new HttpClient();
            client.BaseAddress = new Uri("http://codecamp.westeurope.cloudapp.azure.com");

            var httpResponse = await client.GetAsync("api/color/" + boxId);
            var jsonResponse = await httpResponse.Content.ReadAsStringAsync();

            var results = JsonConvert.DeserializeObject<Dictionary<string, string>>(jsonResponse);
            SetBoxDisplay(results);
            SetRequestCountPerNode(results);          
        }

        private void SetBoxDisplay(Dictionary<string, string> results)
        {
            var box = this.boxes.Single(b => b.Name == "box" + results["Id"]);
                        
            box.Text = "N" + results["NodeName"];
            box.Text += " " + results["RequestCount"];

            box.BackColor = Color.FromName(results["Color"]);
        }

        private void SetRequestCountPerNode(Dictionary<string, string> results)
        {
            var node = this.nodes.Single(n => n.Name == "label" + results["NodeName"]);
            var requestsCountPerNode = Convert.ToInt32(node.Tag) + 1;
            node.Tag = requestsCountPerNode;
            node.Text = "Node " + results["NodeName"] + ": " + node.Tag;
            node.Refresh();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            CreateAndAddNodes();
            CreateNodeLabels();
        }

        private Button CreateBoxes(int id)
        {
            var button = new Button();
            button.Enabled = false;
            button.Width = 50;
            button.Height = 50;
            button.Padding = new Padding(0);
            button.FlatStyle = FlatStyle.Flat;
            button.FlatAppearance.BorderSize = 0;
            button.Font = new Font("Arial", 11);
            button.Name = "box" + id;
            return button;           
        }

        private void CreateNodeLabels()
        {
            for (int i = 0; i < 5; i++)
            {
                var label = new Label();
                label.Name = "label" + i;
                label.Text = "Node " + i;
                label.Tag = "0";
                label.Width = 130;
                label.Font = new Font("Arial", 13);
                this.nodeLabels.Controls.Add(label);
                nodes.Add(label);
            }
        }

        private static string GetBoxId(object sender)
        {
            var timer = (Timer)sender;
            var boxId = timer.Tag;
            return boxId.ToString();
        }

        public Form1()
        {
            InitializeComponent();
        }

        List<Button> boxes = new List<Button>();
        List<Label> nodes = new List<Label>();        
    }
}
