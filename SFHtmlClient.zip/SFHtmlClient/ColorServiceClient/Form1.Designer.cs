﻿namespace ColorServiceClient
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.flowLayoutPanel = new System.Windows.Forms.FlowLayoutPanel();
            this.nodeLabels = new System.Windows.Forms.FlowLayoutPanel();
            this.connectionErrors = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // flowLayoutPanel
            // 
            this.flowLayoutPanel.Location = new System.Drawing.Point(12, 49);
            this.flowLayoutPanel.Name = "flowLayoutPanel";
            this.flowLayoutPanel.Size = new System.Drawing.Size(728, 583);
            this.flowLayoutPanel.TabIndex = 0;
            // 
            // nodeLabels
            // 
            this.nodeLabels.Location = new System.Drawing.Point(12, 12);
            this.nodeLabels.Name = "nodeLabels";
            this.nodeLabels.Size = new System.Drawing.Size(728, 31);
            this.nodeLabels.TabIndex = 1;
            // 
            // connectionErrors
            // 
            this.connectionErrors.AutoSize = true;
            this.connectionErrors.Location = new System.Drawing.Point(12, 508);
            this.connectionErrors.Name = "connectionErrors";
            this.connectionErrors.Size = new System.Drawing.Size(0, 13);
            this.connectionErrors.TabIndex = 2;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(752, 669);
            this.Controls.Add(this.connectionErrors);
            this.Controls.Add(this.nodeLabels);
            this.Controls.Add(this.flowLayoutPanel);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel;
        private System.Windows.Forms.FlowLayoutPanel nodeLabels;
        private System.Windows.Forms.Label connectionErrors;
    }
}

