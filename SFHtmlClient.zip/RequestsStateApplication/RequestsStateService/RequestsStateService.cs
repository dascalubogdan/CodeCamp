﻿using System.Collections.Generic;
using System.Fabric;
using System.Threading.Tasks;
using Microsoft.ServiceFabric.Data.Collections;
using Microsoft.ServiceFabric.Services.Communication.Runtime;
using Microsoft.ServiceFabric.Services.Runtime;
using Microsoft.ServiceFabric.Services.Remoting.Runtime;
using Microsoft.ServiceFabric.Services.Remoting;
using Microsoft.ServiceFabric.Data;

namespace RequestsStateService
{
    /// <summary>
    /// An instance of this class is created for each service replica by the Service Fabric runtime.
    /// </summary>
    internal sealed class RequestsStateService : StatefulService, IRequestsStateService
    {
        public RequestsStateService(StatefulServiceContext context)
            : base(context)
        { }

        protected override IEnumerable<ServiceReplicaListener> CreateServiceReplicaListeners()
        {
            return new[] { new ServiceReplicaListener(context => this.CreateServiceRemotingListener(context)) };            
        }

        public async Task<int> GetRequestCount(string boxId)
        {
            var state = await this.StateManager.GetOrAddAsync<IReliableDictionary<string, int>>("state");
            ConditionalValue<int> result;

            using (var tx = this.StateManager.CreateTransaction())
            {                
                await state.AddOrUpdateAsync(tx, boxId, 0, (key, value) => ++value);
                result = await state.TryGetValueAsync(tx, boxId);
                await tx.CommitAsync();
            }      
            
            return result.Value;      
        }
    }

    public interface IRequestsStateService : IService
    {
        Task<int> GetRequestCount(string boxId);
    }
}
