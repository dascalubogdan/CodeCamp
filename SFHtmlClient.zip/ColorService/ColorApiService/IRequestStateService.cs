﻿using Microsoft.ServiceFabric.Services.Remoting;
using System.Threading.Tasks;

namespace RequestsStateService
{
    public interface IRequestsStateService : IService
    {
        Task<int> GetRequestCount(string boxId);
    }
}
