﻿using Microsoft.ServiceFabric.Services.Remoting.Client;
using RequestsStateService;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Fabric;
using System.Threading;
using System.Threading.Tasks;
using System.Web.Http;

namespace ColorApiService.Controllers
{
    [ServiceRequestActionFilter]
    public class ColorController : ApiController
    {        
        public async Task<Dictionary<string, string>> Get(string id)
        {            
            var statefulService = ServiceProxy.Create<IRequestsStateService>(new Uri("fabric:/RequestsStateApplication/RequestsStateService"));
            var requestsCount = await statefulService.GetRequestCount(id);
            
            return new Dictionary<string, string>
            {
                { "Color", "pink" },
                { "NodeName",  GetNodeIdentifier() },               
                { "RequestCount", requestsCount.ToString() },
                { "Id", id },
            };
        }

        private string GetNodeIdentifier()
        {
            var nodeName = FabricRuntime.GetNodeContext().NodeName;
            return nodeName[nodeName.Length - 1].ToString();
        }

        private string GetColorFromConfig()
        {
            CodePackageActivationContext activationContext = FabricRuntime.GetActivationContext();
            var configurationPackage = activationContext.GetConfigurationPackageObject("Config");
            return configurationPackage.Settings.Sections["ConfigSection"].Parameters["Color"].Value;
        }
    }
}
